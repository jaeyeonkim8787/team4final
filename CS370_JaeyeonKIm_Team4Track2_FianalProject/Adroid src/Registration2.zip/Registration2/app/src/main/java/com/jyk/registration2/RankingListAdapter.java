package com.jyk.registration2;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.List;

public class RankingListAdapter extends BaseAdapter {

    private Context context;
    private List<Ranking> rankingList;
    private Fragment parent;
    private String userId = MainActivity.userId;

    public RankingListAdapter(Context context, List<Ranking> rankingList, Fragment parent) {
        this.context = context;
        this.rankingList = rankingList;
        this.parent = parent;
    }

    @Override
    public int getCount() {
        return rankingList.size();
    }

    @Override
    public Object getItem(int i) {
        return rankingList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        View v = View.inflate(context, R.layout.rankings, null);
        TextView ranking_id = v.findViewById(R.id.ranking_id);
        TextView ranking_score = v.findViewById(R.id.ranking_score);
        TextView ranking_date = v.findViewById(R.id.ranking_date);

        ranking_id.setText("ID : " + rankingList.get(i).getId());
        ranking_score.setText("SCORE : " + rankingList.get(i).getScore());
        ranking_date.setText("DATE : " + rankingList.get(i).getDate());

        v.setTag(rankingList.get(i).getId());
        return v;
    }


}


