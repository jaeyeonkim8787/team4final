package com.jyk.registration2;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class getRankingRequest extends StringRequest {

    final static private String URL = "http://3.18.107.75:8080/AndroidDB3/getRanking.jsp";

    private Map<String, String> parameters;

    public getRankingRequest(String userId, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);
        parameters = new HashMap<>();
        parameters.put("userId", userId);

    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return parameters;
    }

}
