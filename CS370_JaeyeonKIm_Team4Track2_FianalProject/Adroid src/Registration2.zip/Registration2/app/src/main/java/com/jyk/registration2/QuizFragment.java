package com.jyk.registration2;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link QuizFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class QuizFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public QuizFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BlankFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static QuizFragment newInstance(String param1, String param2) {
        QuizFragment fragment = new QuizFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    private String answer0;
    private String answer1;
    private String answer2;
    private String answer3;
    private String answer4;
    private int sum = 0;
    private AlertDialog dialog;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        final RadioGroup rg0 = getView().findViewById(R.id.quizGroup0);
        int id0 = rg0.getCheckedRadioButtonId();

        rg0.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb0 = getView().findViewById(checkedId);
                answer0 = rb0.getText().toString();
            }
        });

        final RadioGroup rg1 = getView().findViewById(R.id.quizGroup1);
        rg1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb1 = getView().findViewById(checkedId);
                answer1 = rb1.getText().toString();
            }
        });

        final RadioGroup rg2 = getView().findViewById(R.id.quizGroup2);
        rg2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb2 = getView().findViewById(checkedId);
                answer2 = rb2.getText().toString();
            }
        });

        final RadioGroup rg3 = getView().findViewById(R.id.quizGroup3);
        rg3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb3 = getView().findViewById(checkedId);
                answer3 = rb3.getText().toString();
            }
        });

        final RadioGroup rg4 = getView().findViewById(R.id.quizGroup4);
        rg4.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb4 = getView().findViewById(checkedId);
                answer4 = rb4.getText().toString();
            }
        });

        final Button scoreButton = getView().findViewById(R.id.scoreButton);
        scoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ("X".equals(answer0)) {
                    sum += 20;
                }
                if ("O".equals(answer1)) {
                    sum += 20;
                }
                if ("X".equals(answer2)) {
                    sum += 20;
                }
                if ("O".equals(answer3)) {
                    sum += 20;
                }
                if ("X".equals(answer4)) {
                    sum += 20;
                }

                TextView score = getView().findViewById(R.id.score);
                score.setText(Integer.toString(sum));

                TextView result0 = getView().findViewById(R.id.result0);
                TextView result1 = getView().findViewById(R.id.result1);
                TextView result2 = getView().findViewById(R.id.result2);
                TextView result3 = getView().findViewById(R.id.result3);
                TextView result4 = getView().findViewById(R.id.result4);

                result0.setVisibility(View.VISIBLE);
                result1.setVisibility(View.VISIBLE);
                result2.setVisibility(View.VISIBLE);
                result3.setVisibility(View.VISIBLE);
                result4.setVisibility(View.VISIBLE);

                RadioButton rb0_O = getView().findViewById(R.id.quiz0_O);
                RadioButton rb0_X = getView().findViewById(R.id.quiz0_X);
                rb0_O.setEnabled(false);
                rb0_X.setEnabled(false);

                RadioButton rb1_O = getView().findViewById(R.id.quiz1_O);
                RadioButton rb1_X = getView().findViewById(R.id.quiz1_X);
                rb1_O.setEnabled(false);
                rb1_X.setEnabled(false);

                RadioButton rb2_O = getView().findViewById(R.id.quiz2_O);
                RadioButton rb2_X = getView().findViewById(R.id.quiz2_X);
                rb2_O.setEnabled(false);
                rb2_X.setEnabled(false);

                RadioButton rb3_O = getView().findViewById(R.id.quiz3_O);
                RadioButton rb3_X = getView().findViewById(R.id.quiz3_X);
                rb3_O.setEnabled(false);
                rb3_X.setEnabled(false);

                RadioButton rb4_O = getView().findViewById(R.id.quiz4_O);
                RadioButton rb4_X = getView().findViewById(R.id.quiz4_X);
                rb4_O.setEnabled(false);
                rb4_X.setEnabled(false);

            }
        });


        final Button submitButton = getView().findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("userId : " + MainActivity.userId);
                System.out.println("score : " + sum);

                new BackgroundTask().execute();
            }
        });
    }

    class BackgroundTask extends AsyncTask<Void, Void, String> {

        String target;

        @Override
        protected void onPreExecute() {
            System.out.println("@@@ MainActivity.userId : " + MainActivity.userId);
            String score = Integer.toString(sum);
            System.out.println("@@@ score : " + score);

            target = "http://3.18.107.75:8080/AndroidDB3/addRanking.jsp?userId=" + URLEncoder.encode(MainActivity.userId)
                + "&score=" + URLEncoder.encode(score);

            System.out.println("@@@ target.userId : " + target);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(target);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String temp;
                StringBuilder stringBuilder = new StringBuilder();
                while ((temp = bufferedReader.readLine()) != null) {
                    stringBuilder.append(temp + "\n");
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return stringBuilder.toString().trim();
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        public void onProgressUpdate(Void... values) {
            super.onProgressUpdate();
        }

        @Override
        public void onPostExecute(String result) {
            try {
                System.out.println("result : " + result);
                JSONObject jsonObject = new JSONObject(result);
                String msg = jsonObject.getString("msg");
                System.out.println("msg : " + msg);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
   }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_quiz, container, false);
    }





}
