package com.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class ConnectDB {
    private static ConnectDB instance = new ConnectDB();

    public static ConnectDB getInstance() {
        return instance;
    }
    public ConnectDB() {  }

    // oracle ����
    String jdbcUrl = "jdbc:oracle:thin:@192.168.20.53:1521:xe";
    String userId = "dev";
    String userPw = "oracle";

    Connection conn = null;
    PreparedStatement pstmt = null;
    PreparedStatement pstmt2 = null;
    ResultSet rs = null;

    String sql = "";
    String sql2 = "";
    String msg = "ERROR";

    private String url = "jdbc:mysql://3.18.107.75:3306/jyk2?user=root&password=root1234";
    
    public String connectionDB(String userId, String userPassword, String userEmail) {
    	
    	System.out.println("userId : " + userId);
    	System.out.println("userPassword : " + userPassword);
    	System.out.println("userEmail : " + userEmail);
    	
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	conn = DriverManager.getConnection(url);

            sql = "SELECT id FROM user WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);

            rs = pstmt.executeQuery();
            if (rs.next()) {
            	msg = "already exists";
            } else {
                sql2 = "INSERT INTO user (id, password, email) VALUES(?,?,?)";
                pstmt2 = conn.prepareStatement(sql2);
                pstmt2.setString(1, userId);
                pstmt2.setString(2, userPassword);
                pstmt2.setString(3, userEmail);
                pstmt2.executeUpdate();
                msg = "register success";
            }
        } catch (Exception e) {
        	msg = e.getMessage();
            e.printStackTrace();
        } finally {
        	if (rs != null)try {rs.close();    } catch (SQLException ex) {}
            if (pstmt2 != null)try {pstmt2.close();    } catch (SQLException ex) {}
            if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
            if (conn != null)try {conn.close();    } catch (SQLException ex) {    }
        }
        
        JSONObject json = new JSONObject();
        json.put("msg", msg);
        return json.toString();
    }
    
    public String login(String userId, String userPassword) {
    	
    	System.out.println("userId : " + userId);
    	System.out.println("userPassword : " + userPassword);
    	
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	conn = DriverManager.getConnection(url);

            sql = "SELECT id, password FROM user WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);

            rs = pstmt.executeQuery();
            if (rs.next()) {
            	if (userPassword.equals(rs.getString(2))) {
            		msg = "login success";
        		} else {
        			msg = "Passwords do not match";
        		}
            } else {
                msg = "ID does not exist"; 
            }
        } catch (Exception e) {
        	msg = e.getMessage();
            e.printStackTrace();
        } finally {
        	if (rs != null)try {rs.close();    } catch (SQLException ex) {}
            if (pstmt2 != null)try {pstmt2.close();    } catch (SQLException ex) {}
            if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
            if (conn != null)try {conn.close();    } catch (SQLException ex) {    }
        }
        
        JSONObject json = new JSONObject();
        json.put("msg", msg);
        return json.toString();
    }
    
    public String getRanking(String userId) {
    	
    	System.out.println("userId : " + userId);
    	
    	JSONArray jarr = new JSONArray();
    	
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	conn = DriverManager.getConnection(url);
        	
            sql = "SELECT id, score, date FROM ranking order by score desc, date desc";
            pstmt = conn.prepareStatement(sql);
            //pstmt.setString(1, userId);
            
            rs = pstmt.executeQuery();
            while (rs.next()) {
            	JSONObject temp = new JSONObject();
            	temp.put("id", rs.getString(1));
            	temp.put("score", rs.getString(2));
            	temp.put("date", rs.getString(3));
            	jarr.add(temp);
            }
            
        } catch (Exception e) {
        	msg = e.getMessage();
            e.printStackTrace();
        } finally {
        	if (rs != null)try {rs.close();    } catch (SQLException ex) {}
            if (pstmt2 != null)try {pstmt2.close();    } catch (SQLException ex) {}
            if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
            if (conn != null)try {conn.close();    } catch (SQLException ex) {    }
        }
        
        JSONObject json = new JSONObject();
        json.put("response", jarr);
        json.put("msg", msg);
        return json.toJSONString();
    }

	public String addRanking(String userId, String score) {
		
		System.out.println("userId : " + userId);
		System.out.println("score : " + score);
		
	    try {
	    	Class.forName("com.mysql.jdbc.Driver");
	    	conn = DriverManager.getConnection(url);
	        
	        sql = "INSERT INTO ranking (id, score, date) VALUES(?, ?, now())";
	        pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, userId);
            pstmt.setString(2, score);
            //pstmt.setString(3, "now()");
            
	        int res = pstmt.executeUpdate();
	        if (res == 1) {
	        	msg = "registration success";
	        } else {
	        	msg = "registration fail";
	        }
	        
	    } catch (Exception e) {
	    	msg = e.getMessage();
	        e.printStackTrace();
	    } finally {
	    	if (rs != null)try {rs.close();    } catch (SQLException ex) {}
	        if (pstmt2 != null)try {pstmt2.close();    } catch (SQLException ex) {}
	        if (pstmt != null)try {pstmt.close();} catch (SQLException ex) {}
	        if (conn != null)try {conn.close();    } catch (SQLException ex) {    }
	    }
	    
	    JSONObject json = new JSONObject();
	    json.put("msg", msg);
	    return json.toString();
	}
    
    
}